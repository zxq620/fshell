#include<stdio.h>

void main(){
        puts("已实现的命令如下：\ncat cp lsdir pwd rm help touch mv cd mkdir\n");
        return ;
}
