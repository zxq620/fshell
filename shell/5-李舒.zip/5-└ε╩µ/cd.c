#include<stdio.h>
#define PATH_SIZE 100
#define BUF_SIZE 64
int cds(const char *p)
{
        char path[PATH_SIZE];
        char *start;
        char *end;
        int res;
        int n= 0;

        memset(path,'\0',PATH_SIZE); // must init 
        start = strchr(p,' ');
        end = strchr(p,'\n');
        if(!start || !end)
        {
                printf("can't support this format \n");
                return 1;
        }

        strncpy(path,p+3,end-start-1); // get the path in inputting command

        res = chdir(path); //range dir

        if(res != 0)
                printf("%s is nod a path,please check again \n",path);

        return res;
}
int main(int argc, char *argv[])
{
char buf[BUF_SIZE];
printf("|->");
fgets(buf,BUF_SIZE,stdin);
cds(buf);
printf("you have cd successfully,the directory now is:\n");
}
