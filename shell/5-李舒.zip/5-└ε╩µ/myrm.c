			
 #include <unistd.h> 
 #include <stdio.h> 
 #include <stdlib.h> 

 int main(int argc , char * argv[]) { 

  int rt; 
  if(argc != 2){  //限制参数个数为2，返回错误或退出 ：rm+文件名
    exit(2);   
  }else{ //命令格式正确

    if((rt = unlink(argv[1])) !=  0){ //若返回值不为0，则删除失败
        fprintf(stderr,"error."); //提示出错信息
        exit(3); 
    } 

  } 

  return 0; 

 } 
