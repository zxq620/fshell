#include "exit.h"

void fun_exit(){
	printf("=======================\n");
    printf("BBBBB  Y     Y  EEEEEE \n");
    printf("B    B  Y   Y   E      \n");
    printf("B    B   Y Y    E      \n");
    printf("BBBBB     Y     EEEEEE \n");
    printf("B    B    Y     E      \n");
    printf("B    B    Y     E      \n");
    printf("BBBBB     Y     EEEEEE \n");
    printf("=======================\n\n");
	printf("Thank for your using,bye-bye!\n");
	sleep(1);
	exit(0);//ֱ���˳�
}
