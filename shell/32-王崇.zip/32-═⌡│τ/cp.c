#include<stdio.h>
#include<unistd.h>
#include<errno.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<sys/types.h>
#include<string.h>

//Function：
//实现的cp功能 可以从文件复制到指定文件夹下 但是没有实现带参数cp
//另外如果多次复制并不会提示是否两者都保存，直接删除原文件重新复制
//另外注意在文件夹下创建的文件可能带有文件夹锁，导致下一次复制访问该文件失败


int main(int argc, char *argv[])
{
	int fd,fd1,size;
	int readnumber,writenumber;
	struct stat statbuf,statbuf1; 
	char tempor[1024];
	if(argc != 3)
	{
		printf("please enter the right source and destination:\n");
		return 0;
	}

	fd = open(argv[1],O_RDONLY,777);
	if(fd < 0)
	{
		perror("open wrong!");
		return 0;
	}

//怎样事先判断文件的大小呢

//这里有个好方法 用stat结构读取
	stat(argv[1],&statbuf);
	size = statbuf.st_size;
	readnumber = read(fd,tempor,size);
	printf("you have read %d words \n",readnumber);

    //若输入的第二个是一个文件夹的路径，怎么写呢？ fopen不是系统调用函数，使用的话内外核切换浪费很大
    //如果目标文件是一个目录，那么我的方法是将其文件夹路径补全为一个文件路径*/
    stat(argv[2],&statbuf1);
    //这里有一个错误，就是不进行判断，直接都走else了，但是我真的累了，找不出来
    if(S_ISDIR(statbuf1.st_mode) != 0)
    {
    	//这里注意当第一个参数不是路径而只是一个文件的时候的情况
    	if(S_ISDIR(statbuf.st_mode))//等于0的话是文件
    	{
	    	char ch = '/';
	    	char *q = strrchr(argv[1],ch);
	    	printf("%s\n", q);
	    	strcat(argv[2],q);//连接字符串函数,即自动将路径补全了

    	}else 
    	{
    		char *p = "/";
    		strcat(argv[2],p);
    		strcat(argv[2],argv[1]);
    	 }
    }
}
	chmod(argv[2],S_IRUSR|S_IWUSR);
	printf("%s\n",argv[2] );
	fd1 = open(argv[2],O_WRONLY|O_CREAT,777);
	//注意这里若文件存在的话会报错，原因ubuntuyou 文件夹锁，创造的文件只能读，修改一下权限就好了	
	if(fd1 < 0)
	{
		perror("open wrong!");
		return 0;
	}
 
	writenumber = write(fd1,tempor,readnumber);
	printf("you have write %d words \n",writenumber);


	close(fd); 
	close(fd1);


	return 0;
}
