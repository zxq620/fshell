int parsecommand(char buff[],char *inputs[]){
bzero(inputs,MAX_CMD);
int in=0;
char *p=buf;
int i=0;
while(*p==''){
     p++;
     i++;
}
inputs[in]=p;
in++;
int i1=i;
int len=strlen(buf);
for(i;i<=len;i++){
if(buf[i]==''){
   buf[i]='\0';
}
}
i1++;
p++;
for(i1;i1<=len;il++,p++){
if(buf[i1-1]='\0'){
  inputs[in]=p;
  in++;
}
}
inputs[in]=NULL;
return in;
}
