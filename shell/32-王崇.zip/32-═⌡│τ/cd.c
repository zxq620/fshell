#include <stdio.h>
void main()
{
     char dirPath[MAX_PATH] = "";
     char cmdln1[256] = "";
     char cmdln2[256] = "";
     char *p, *q;
     HANDLE hFile = INVALID_HANDLE_VALUE;
     GetModuleFileName(NULL, dirPath, MAX_PATH);
     p = dirPath;
     while((p = strpbrk(p, "\\")) != NULL)
     {
         q = p;
         p++;
     }
     *q = '\0';
     strcat(dirPath, ">");
     printf("%s", dirPath);
     while(1)
     {
         scanf("%s", cmdln1);
         if (strcmp(cmdln1, "cd..") == 0)
         {
             p = dirPath;
             while((p = strpbrk(p, "\\")) != NULL)
             {
                 q = p;
                 p++;
             }
             *q = '\0';
             strcat(dirPath, ">");
                 printf("%s", dirPath);
         }else{
             scanf("%s", cmdln2);
             if (strcmp(cmdln2, "\\") == 0)
             {
                 p = strpbrk(dirPath, "\\");
                 *(p+1) = '\0';
                 strcat(dirPath, ">");
                 printf("%s", dirPath);
             }else{
                 p = dirPath;
  while(*p != '\0')
                     p++;
                 p--;
                 if (*(p - 1) != '\\')
                 {
                     *p = '\\';
                 }else{
                     *p = '\0';
                 }
                 strcat(dirPath, cmdln2);
                 hFile = CreateFile(dirPath, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, 
                     NULL, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, NULL);
                 if (hFile != INVALID_HANDLE_VALUE)
                 {
                     CloseHandle(hFile);
                     strcat(dirPath, ">");
                     printf("%s", dirPath);
                 }else{
                     printf("no this directery!\n");
                     *p = '\0';
                     strcat(dirPath, ">");
                     printf("%s", dirPath);
                 }
             }
         }
     }
} 
