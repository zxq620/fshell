#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include<math.h>
# define BUFFER_LEN 4096

void showAll(char *filename,int sw){
	FILE *fp;
    char StrLine[1024];             //每行最大读取的字符数
    if((fp = fopen(filename,"r")) == NULL) //判断文件是否存在及可读
    {
        printf("error!");
    }
	
	int i=0;
    while (!feof(fp)){
       fgets(StrLine,1024,fp);  //读取一行
       if(sw==0)
       		printf("%s\n", StrLine);
       if(sw==1){
            printf("%d  %s", i, StrLine); //输出
            i++;
       }
       if(sw==2){
       		if(strcmp(StrLine,"\n")!=0){
       			printf("%d  %s", i, StrLine);
       			i++;
       		}else printf("%s", StrLine);
       }
       if(sw==8){
       		printf("%s$", StrLine);
       }
    }
    fclose(fp);    
}

int main(int argc, char *argv[]){

	if (argc == 1){
		while(1){
			char a[256];
			fgets(a,256,stdin);
			printf("%s",a);
		}
	}else{
		int sw=0;
		char *ch[]={"n","b","s","E","T"};
		
		for(int j=1;j<argc;j++){
			if(strpbrk(argv[j],"-")!=0){
				for(int i=0;i<5;i++){
					if(strpbrk(argv[j],ch[i])!=0)
						sw+=(int)pow(2,i);
				}
			}
		}
		//printf("%d",sw);
		for(int j=1;j<argc;j++){
			if(strpbrk(argv[j],"-")==0){
				showAll(argv[j],sw);
			}
		}
		
	}
	return 0;
 }
