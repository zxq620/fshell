#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "cd.c"
#include "pwd.c"
#include "ls.c"
#include "ls2.c"
#include "clear.c"
#include "mkdir.c"
#include "rmdir.c"
#include "cp.c"
#include "cat.c"
#include "ps.c"
#include "who.c"
#include "date.c"
#include "rm.c"
#include "ping.c"
#include "tac.c"

#include "t.h"

#define MAXSIZE 1024

int commandHandler(int argc,char *args[]){
    
    //strcmp(str1,str2)，若str1=str2，则返回零；若str1<str2，则返回负数；若str1>str2，则返回正数。
    if(strcmp(args[0],"exit") == 0){
        exit(0);
    }else if(strcmp(args[0],"cd") == 0){
        changeDirectiry(args);
    }else if(strcmp(args[0],"pwd") == 0){
        printWorkingDirectiry();
    }else if(strcmp(args[0],"clear") == 0){
        clear();
    }else if(strcmp(args[0],"mkdir") == 0){
        makeDirectiry(argc,args);
    }else if(strcmp(args[0],"rm") == 0){
        remove2(argc,args);
    }else if(strcmp(args[0],"ls") == 0 && args[1]==NULL){
        listFiles();
    }else if(strcmp(args[0],"ls") == 0 &&strcmp(args[1],"-l") == 0){
        listFilesL();
    }else if(strcmp(args[0],"ls") == 0 ){
        listFiles2(argc,args);
    }else if(strcmp(args[0],"cp") == 0){
        copyFiles(args);        
    }else if(strcmp(args[0],"cat") == 0){
        cat(argc,args);       
    }else if(strcmp(args[0],"ps") == 0){
        processStatus();
    }else if(strcmp(args[0],"who") == 0 && args[1]==NULL){
        opt_No();
    }else if(strcmp(args[0],"who") == 0 && strcmp(args[1],"-q") == 0){
        opt_q();
    }else if(strcmp(args[0],"who") == 0 && strcmp(args[1],"-H") == 0){
        opt_H();
    }else if(strcmp(args[0],"date") == 0 ){
        date(argc,args);
    }else if(strcmp(args[0],"ping") == 0 ){
        ping(argc,args);
    }else if(strcmp(args[0],"tac") == 0 ){
        tac(argc,args);
    }
    else{
        printf("%s不是可用的命令\n",args[0]);
    }
    return 1;
}