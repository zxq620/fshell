#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

//char currentDirectory[1024]="";
void printWorkingDirectiry(){ // pwd
    printf("%s\n",getcwd(currentDirectory,1024));
}