#include <stdio.h>
#include <stdlib.h>

void welcomeScreen(){
        printf("\n\t============================================\n");
        printf("\t               Simple C Shell\n");
        printf("\t--------------------------------------------\n");
        printf("\t      Author: 刘晨 王禧龙 黄正彬\n");
        printf("\t============================================\n");
        printf("\n\n");
}