为了实现ping命令：
编译： gcc -o main main.c -lpthread
运行： sudo ./main

ping cat date ls mkdir ps who rm tac cd cp pwd clear

ping 用于检测主机

cat        
cat   -n   显示行数
cat   -E   显示$$$
-n  -E

date  显示当前时间 pst
date -u gmt
date -I  年月日 

ls 
ls . 本级目录
ls .. 上级目录
ls -a 显示所有 包括隐藏 和.  ..
ls -l  显示权限
ls -r  反向输出

mkdir
mkdir -v  显示创建成功信息
mkdir -p 递归创建目录，即使上级目录不存在，会按目录层级自动创建目录

ps 打印进程详细信息

who 显示当前登录系统的用户
who -q 实现用户计数
who -H 显示各栏位的标题信息列；

pwd 打印当前工作目录

cd 切换工作目录

cp 实现文件的复制

clear 清除屏幕

rm 删除文件或者空文件夹
rm -v 显示详细信息
rm -i 交互式删除

tac 倒叙打印文件




















