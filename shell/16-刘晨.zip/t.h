#ifndef __T_H__
#define __T_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void welcomeScreen();
void shellPrompt();
int cat(int argc,char *args[]);
int changeDirectiry(char *args[]);
void clear();
void copyFiles(char *args[]);
void listFiles();
void listFilesL();
int listFiles2(int argc, char** argv);
int makeDirectiry(int argc, char** argv);
int remove2(int argc, char ** argv);
void printWorkingDirectiry();
int commandHandler(int argc,char *args[]);
void processStatus();
void opt_q();
void opt_H();
void opt_No();
int date(int argc,char *args[]);
int ping(int argc, char* argv[]);
int tac(int argc, char *argv[]);
#endif // !__T_H__
