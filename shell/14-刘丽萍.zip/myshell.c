#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <libgen.h>
#define MAX_CMD 100
#define MAX_DIR_NAME 100
#define MAXX 100

void eval(char *cmdstring)
{
char *argv[MAX_CMD];
char buf[MAX_CMD];
strcpy(buf,cmdstring);
parseline(buf,argv);
if (argv[0]==NULL)
{
return ;
}
if (buildin_command(argv)) return;
int pid=fork();
if(pid==0){
if (execvp(argv[0],argv)<0)
{
printf("%s:command error.\n",argv[0]);
exit(0);
}
}
wait(pid);
}

int argc;
int parseline(char *buf,char**argv)
{
while(*buf==' ')
{
buf++;
}

int delim=0;
argc=0;
while(*buf!='\n')
{
while(buf[delim]!='\n' && buf[delim]!=' ')
{
delim++;
}
if (buf[delim]=='\n')
{
buf[delim]='\0';
argv[argc++]=buf;
break;
}
buf[delim]='\0';
argv[argc++]=buf;

buf+=delim+1;
delim=0;
while(*buf==' ')
{
buf++;
}
}
argv[argc]=NULL;
return 0;
}


int buildin_command(char **argv)
{
if (strcmp(argv[0],"pwd")==0)
{
char buf[MAX_DIR_NAME];
printf("%s\n",getcwd(buf,sizeof(buf)));
return 1;
}

if (strcmp(argv[0],"cd")==0)
{

if (chdir(argv[1])==0)
{
printf("修改成功\n");
}
else
{
printf("myselous:cd:%s\n",argv[1]);
}
return 1;
}

if (strcmp(argv[0],"exit")==0){
exit(0);
}

if (strcmp(argv[0],"echo")==0){
int x=1;
while (x<argc){
printf("%s ",argv[x]);
x++;
}
puts("");
return 1;
}

if (strcmp(argv[0],"mkdir")==0){
if(argc<=1){
printf("mkdir:Usage:dirstr\n");
exit(1);
}
char data[MAXX];
if ((strcmp(argv[1],".")==0) || strcmp(argv[1],"/")==0)
return ;
if (access(argv[1],F_OK)==0){
return ;
}else{
strcpy(data,argv[1]);
dirname(argv[1]);
}
if (mkdir(data,777)==-1){
printf("mkdir error");
exit(1);
}
return 1;
}

if (strcmp(argv[0],"cat")==0){
FILE *fp;
if (argc==1){
int c;
while ((c=getc(stdin))!=EOF)
putc(c,stdout);
}
else{
while(--argc>0)
{
if ((fp=fopen(*++argv,"r"))==NULL){
//printf("no such file %s",*argv);
return 1;
}
else{
int c;
while ((c=getc(fp))!=EOF)
putc(c,stdout);
fclose(fp);
}
}
}
return 1;
}

if (strcmp(argv[0],"cp")==0){
if (argc<3)
{
printf("传入参数少，应输入./main filename destname\n");
return 1;
}
int fd;
int buf_fd;
int buf_size;
char buf_addr[100]={0};
buf_fd=open(argv[1],O_RDWR);
buf_size=lseek(buf_fd,0,SEEK_END);
//printf("buf_size is :%d\n",buf_size);
lseek(buf_fd,-buf_size,SEEK_CUR);
read(buf_fd,buf_addr,buf_size);
//printf("buf_addr is :%s\n",buf_addr);
fd=open(argv[2],O_CREAT|O_RDWR|O_TRUNC);
if (fd==1){
printf("failed");
return 1;
}else{
write(fd,buf_addr,buf_size);
printf("复制成功\n");
}
close(fd);
close(buf_fd);

return 1;
}

if (strcmp(argv[0],"rm")==0){
if (argc!=2)
printf("wrong\n");
if (remove(argv[1])!=0)
perror("remove"),exit(-1);
printf("remove %s success\n",basename(argv[1]));
return 1;
}

}


int main (int argc,char *argv[])
{
char cmdstring[MAX_CMD];
int n;
while(1)
{
printf("myshell>");
fflush(stdout);
if ((n=read(0,cmdstring,MAX_CMD))<0)
{
printf("error");
}
eval(cmdstring);
}
return 0;
}

