#include <stdio.h>
#include <dirent.h>
#include <unistd.h>
#include <sys/types.h>
#include <string.h>

int main()
{

    DIR *dirptr=NULL;
    struct dirent *current_dirent=NULL, *parent_dirent=NULL, *tmp_dirent=NULL;
    int count=0;
    ino_t current_inode;
    char path[256][256];

    while(1)
    {
        dirptr=opendir(".");
        do
        {
            current_dirent=readdir(dirptr);
        }while(strcmp(current_dirent->d_name, ".")!=0);
        current_inode=current_dirent->d_ino;
        closedir(dirptr);
        dirptr=opendir(".");
        do
        {
            parent_dirent=readdir(dirptr);
        }while(strcmp(parent_dirent->d_name, "..")!=0);
        closedir(dirptr);
        if(((long)parent_dirent->d_ino)==((long)current_dirent->d_ino))
        {
            break;
        }
        else
        {
            chdir("..");
            dirptr=opendir(".");
            do
            {
                tmp_dirent=readdir(dirptr);
            }while(tmp_dirent->d_ino!=current_inode);
            closedir(dirptr);
            count++;
            strcpy(path[count], tmp_dirent->d_name);
        }
    }
    int i;
    for(i=count;i>0;i--)
    {
        printf("/%s", path[i]);
    }
	printf("\n");

    return 0;
}
