#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

void gettime(char *cur_time) {
        char Year[6] = {0};
        char Month[4] = {0};
        char Day[4] = {0};
        char Hour[4] = {0};
        char Min[4] = {0};
        char Sec[4] = {0};

        time_t current_time;
        struct tm* now_time;
        time(&current_time);
        now_time = localtime(&current_time);

        strftime(Year, sizeof(Year), "%Y-", now_time);
        strftime(Month, sizeof(Month), "%m-", now_time);
        strftime(Day, sizeof(Day), "%d ", now_time);
        strftime(Hour, sizeof(Hour), "%H:", now_time);
        strftime(Min, sizeof(Min), "%M:", now_time);
        strftime(Sec, sizeof(Sec), "%S", now_time);

        strncat(cur_time, Year, 5);
        strncat(cur_time, Month, 3);
        strncat(cur_time, Day, 3);
        strncat(cur_time, Hour, 3);
        strncat(cur_time, Min, 3);
        strncat(cur_time, Sec, 3);
}

int main() {
        char *cur_time = (char *)malloc(21*sizeof(char));
        gettime(cur_time);
        printf("Current time: %s\n", cur_time);
        free(cur_time);
        cur_time = NULL;
        return 0;
}
