#include<stdio.h>
int main(){
	int i=1,j;
	while(1){
		j=1;
		while(1){
			printf("%-4d",i*j);
			j++;
			if(j>4)break;
		}
		printf("\n");
		i++;
		if(i>4)break;
	}
	return 0;
}
