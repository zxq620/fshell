#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define STR_LEN 30
const char exit_str[] = "exit" ;
int main(void){
    char str[STR_LEN];
    while(1){
        scanf("%s" ,str );
        if(strcmp(str ,exit_str )==0)
            exit(0);
    }
    return 0;
}

