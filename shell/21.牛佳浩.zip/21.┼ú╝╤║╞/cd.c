#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){
    char pwd[1000];
    gets(pwd);
    printf("%s\n",pwd);
    if(chdir(pwd)==-1){perror("chdir");exit(1);}
    getcwd(pwd,1000);
    printf("%s\n",pwd);
    return 1;
}