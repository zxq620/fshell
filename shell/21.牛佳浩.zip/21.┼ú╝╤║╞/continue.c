#include <stdio.h>
int main(void){
    int sum,i;
    sum=0;
    for(i=1; i<=100; i++){
        sum=sum+i;
        if(i==2){
            printf( "Execute continue" );
            continue;
        }
        if(i==4){
            printf( "Execute break" );
            break;
        }
        printf("sum=%d",sum);
    }
    printf("end");
    return 0;
}
