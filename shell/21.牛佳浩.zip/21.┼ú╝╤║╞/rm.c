#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <libgen.h>
int main(int argc,char* argv[])
{
    int ret;
    if(argc != 2)
    {
        printf("input format error!");
        return 1;
    }
    else
    {
        if((ret=unlink(argv[1]))!=0)
        {
            fprintf(stderr,"error");
            exit(3);
        }
    }
  return 0;
}
