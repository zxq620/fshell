#include<stdio.h>
int main(void)
{
	int variable;
	printf("Please input number you want");
	scanf("5d",&variable);
	switch(variable)
	{
		case 1:
			printf("one!\n");
			break;
		case 2:
			printf("two!\n");
                        break;
		case 3:
			printf("three!\n");
                        break;
		default:
			printf("The current input does not exist,please re-enter\n");
	}
	return 0;
}
