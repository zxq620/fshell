#include<stdlib.h>
#include<stdio.h>
void main()
{
	system("tasklist");
	system("pause");
}
